/* beacon.h - COFF BOF (Beacon Object File) API declarations.
 * Compatible with Cobalt Strike 4.x BOF semantics; Havoc implements the same
 * entry point (go) and the same Beacon* runtime API.
 *
 * The loader resolves these symbols against the beacon process, so they must
 * remain undefined externals in the object we ship.
 */
#ifndef BD_BEACON_H
#define BD_BEACON_H

#include <windows.h>

/* output types */
#define CALLBACK_OUTPUT  0x0
#define CALLBACK_OUTPUT_OEM  0x1
#define CALLBACK_OUTPUT_UTF8 0x2
#define CALLBACK_ERROR   0x0d

typedef struct formatp {
    char *original;
    int   size;
} formatp;

void   BeaconDataParse(formatp *format, char *buffer, int size);
int    BeaconDataInt(formatp *format);
short  BeaconDataShort(formatp *format);
int    BeaconDataLength(formatp *format);
char  *BeaconDataExtract(formatp *format, int *size);

char  *BeaconGetSpawnTo(BOOL x86, char *buffer, int length);
void   BeaconDataStore(char *key, char *data, int size);
char  *BeaconDataGet(char *key);

void   BeaconPrintf(int type, char *fmt, ...);
void   BeaconOutput(int type, char *data, int len);

#endif /* BD_BEACON_H */
